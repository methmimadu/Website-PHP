@extends('layouts.app')

@section('content')
<div class="container">
    <div class="flex-center position-ref full-height">
        {{-- @if (Route::has('login'))
             <div class="top-right links">
                 @if ( Auth::user()->admin)

                 <a href="{{ url('/material') }}">Update Materials</a>
                 ||
                     <a href="{{ url('/material/create') }}">Add New Materials</a>
                 ||
                     <a href="{{ url('/order') }}">All Orders</a>
                 ||
                     <a href="{{ url('/order/create') }}">Add a Manual Order</a>


                  @else
                     <a href="{{ url('/order/create') }}">Place a Order</a>
                 @endif

               --}}{{--  <a href="{{ url('/edituser') }}">edit</a>
 --}}{{--
             </div>
         @endif--}}
    </div>
    <div class="row">
        <div class="col-md-12 col-md-offset">
            <div class="panel panel-default">

                <div class="panel-heading">Welcome
                    @if ( Auth::user()->admin)

                   <b>Admin</b>  @endif
                    {{ Auth::user()->name}}</div>


                <div class="row">
                <div class="col-md-8 col-md-offset-2">

                    <br><br>
                    @if (Route::has('login'))
                        <div class="top-right links">
                            @if ( Auth::user()->admin)

                                {{----}}

                               {{-- <div id="tab" class="btn-group" data-toggle="buttons-radio">
                                    <a href="{{ url('/material') }}" class="btn btn-large btn-info" data-toggle="tab">Update Materials</a>
                                    <a href="{{ url('/material/create') }}" class="btn btn-large btn-info" data-toggle="tab">Add New Materials</a>
                                    <a href="{{ url('/order') }}" class="btn btn-large btn-info" data-toggle="tab">All Orders</a>
                                    <a href="{{ url('/order/create') }}" class="btn btn-large btn-info"  data-toggle="tab">Add a Manual Order</a>
                                </div>--}}

                                <a href="{{ url('/material') }}"> <button type="button" class="btn btn-success btn-cons">Update Materials</button></a>
                                <a href="{{ url('/material/create') }}"> <button type="button" class="btn btn-success btn-cons">Add New Materials</button></a>
                                <a href="{{ url('/order') }}"> <button type="button" class="btn btn-success btn-cons">All Orders</button></a>
                                <a href="{{ url('/order/create') }}"> <button type="button" class="btn btn-success btn-cons">Add a Manual Order</button></a>
                                <a href="{{ url('/contact1') }}"> <button type="button" class="btn btn-success btn-cons">Messages</button></a>

                                {{----}}
                             {{--   <a href="{{ url('/material') }}">Update Materials</a>
                                ||
                                <a href="{{ url('/material/create') }}">Add New Materials</a>
                                ||
                                <a href="{{ url('/order') }}">All Orders</a>
                                ||
                                <a href="{{ url('/order/create') }}">Add a Manual Order</a>--}}


                            @else
                                <a href="{{ url('/order/create') }}"> <button type="button" class="btn btn-success btn-cons">Place a Order</button></a>
                                    {{-- <a href="{{ url('/order/create') }}">Place a Order</a>--}}
                            @endif

                            {{--  <a href="{{ url('/edituser') }}">edit</a>
              --}}
                        </div>
                    @endif

 @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif


                    <br><br>

    <p>

    We warmly welcome you for our website. This is your personal account in LA Suppliers web site. Only you can use this account until you keep your password secretly. You can , <br>
• Update material information. <br>
• Add new material.<br>
• Check all martials.<br>
• Add manual orders.<br>
• Check messages from customers.<br>
Via this account. We hope that you will dedicate to serve a valuable service for our customers. 


        </p>
                </div></div>

            </div>
        </div>
    </div>
    {{--Dash board--}}
    {{--Dash board--}}


</div>
@endsection
