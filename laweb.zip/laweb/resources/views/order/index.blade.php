@extends('layouts.app')

@section('content')

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Orders</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="{{ route('order.create') }}"> Place New Order</a>
        </div>
    </div>
</div>

@if ($message = Session::get('success'))
<div class="alert alert-success">
    <p>{{ $message }}</p>
</div>
@endif

<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Customer Name</th>
        <th>Customer Email</th>
        <th>Material Name</th>
        <th>Qty</th>
        <th>Price</th>
        <th>Distance</th>
        <th>Total</th>
        <th width="280px">Action</th>
    </tr>
    @foreach ($order as $key => $item)
    <tr>
        <td>{{ ++$i }}</td>
        <td>{{ $item->cust_name }}</td>
        <td>{{ $item->cust_email }}</td>
        <td>{{ $item->mat_name }}</td>
        <td>{{ $item->qty }}</td>
        <td>{{ $item->price }}</td>
        <td>{{ $item->distance }}</td>
        <td>{{ $item->total }}</td>
       <td>
            <a class="btn btn-primary" href="{{ route('order.edit',$item->id) }}">Edit</a>
            {!! Form::open(['method' => 'DELETE','route' => ['order.destroy', $item->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
        </td>
    </tr>
    @endforeach
</table>

{!! $order->render() !!}

@endsection