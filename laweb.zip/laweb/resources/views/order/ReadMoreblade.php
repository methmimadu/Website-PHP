<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>LA Consrution</title>
       {{-- <script src="{{ asset('js/app.js') }}"></script>--}}
        <script src="{{ asset('js/bootstrap.js') }}"></script>
        <script src="{{ asset('js/jquery.min.js') }}"></script>
        <script src="{{ asset('css/bootstrap.min.css') }}"></script>




        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet" />

        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #ffff00;
                color: #000000;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 50vh;
                margin: 0;
            }

            .full-height {
                /*height: 100vh;*/
                height: 10vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .top-left {
                position: absolute;
                left: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
                color: #000000;
                font-size: 16px;
                font-weight: 600;
                font-family: 'Raleway', sans-serif;

            }



            .title {
                font-size: 84px;
                font-weight: 100;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .custom1{
                font-size: 18px;
               /* color: #080808;!important;*/
                font-weight: 600;

            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">

            <div class="top-left links">
                <img src="img/logo.png" width="40" height="40" >
                <a href="{{ url('/') }}">Home</a>
                <a href="{{ url('/about') }}">About</a>
                <a href="{{ url('/gallery') }}">Gallery</a>
                <a href="{{ url('/contact') }}">Contact Us</a>
            </div>

            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/dashboard') }}">Retun to Dashboard</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                </div>
            @endif
        </div> <br>
        <div class="header-search-box">

                <div class="search-box-wrap" >
                    <form role="search" method="get" class="search-form" action="https://www.gracethemes.com/demo/buildup/">
                        <label>
                            <span class="screen-reader-text">Search for:</span>
                            <input type="search" class="search-field" placeholder="Search&hellip;" value="" name="s" title="Search for:" />
                        </label>
                        <input type="submit" class="search-submit" class="fa fa-search" value="Search" /></form>                </div><!-- .search-box-wrap -->
            </div><!-- .header-search-box -->
            <div class="content">
{{-- Slide Goes Here--}}

                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#my<a href=" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>

                <div class="carousel-inner">
                    <div class="item active"> <img src="img/3.jpg" style="width:100%" data-src="holder.js/900x500/auto/#7cbf00:#fff/text: " alt="First slide">
                        <div class="container ">
                            <div class="carousel-caption" style="background-color:#8e9f93" >
                                <h1>Sand,Rubble,Metal,Soli etc </h1>
                                <p>Deliver to your doorstep</p>
                            </div>
                        </div>
                    </div>
                    <div class="item"> <img src="img/2.jpg" style="width:100%" data-src="" alt="Second slide">
                        <div class="container fontcolor">
                            <div class="carousel-caption" style="background-color:#8e9f93">
                                <h2>
                                Over 1000+ happy Customers
                                </h2>
                                <p> Since 2016,We have the largest customer base in Sri Lanka.</p>
                            </div>
                        </div>
                    </div>
                    <div class="item"> <img src="img/1.jpg" style="width:100%" data-src="" alt="Third slide">
                        <div class="container fontcolor">
                            <div class="carousel-caption" style="background-color:#8e9f93">
                                <h2>
                                   Best place to Start New
                                    </h2>
                                    <p> We have best quality products,</p>
                            </div>
                        </div>
                    </div>
                </div>

                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>

                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a><a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>

                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>

                </div>


{{--End Slide--}}

                <div class="content">
                <h3 class="content"> <b> Welcome to </b> </h3>
                <div class="title m-b-md"> <b> LA Construction </b>
                </div>
                    <hr>
                <h2 class="content" style="text-decoration: underline">About Our Company</h2>

                    <br>
                <p class="content">
                    LA suppliers is a newly started sole proprietor construction company in 2017 that supply building materials.
                    This is situated in Kaduwela.We are hopping to supply building materials such as Sands, Metals, Bricks, Rubble, Soil.
                    Also we hope to provide online ordering facility and check the price of order according to the distance to destination through this web site.
                    Another feature is our customer can use any online pay method to deal with us.
                    We try to be the leading industrial group that has made a giant contribution to the Construction Industry infrastructure growth and technological advancement in Sri Lanka.
                    The RA suppliers Brand name being synonymous with quality, excellence,
                    economy known as a household favorite, a trusted and dependable partner.
                </p>
<div class="custombtn"><a class="morebutton" href="ReadMore.php" target""="">Read More>> </a></div>

            </div>





        </div>
        <br>
        <br>
        <br>
        <hr>
       <section id="pagearea">
    <div class="container">
        <h2 class="section_title">Materials</h2>
        <div class="fourbox ">

            <div class="thumbbx"><a href="#"><img src="img/types/sand.jpg" alt="" /></a></div>
            <div class="pagecontent">
                <a href="#"><h3>SAND</h3></a>
                <p>1 Cube : Rs.16000/=</p>
                
            </div>
        </div>
        <div class="fourbox ">

            <div class="thumbbx"><a href="#"><img src="img/types/corry dust.jpg" alt="" /></a></div>
            <div class="pagecontent">
                <a href="#"><h3>CORRY DUST</h3></a>
                <p>1 Cube : Rs.5500/=</P>
                
            </div>
        </div>
        <div class="fourbox ">

            <div class="thumbbx"><a href="#"><img src="img/types/bricks.jpg" alt="" /></a></div>
            <div class="pagecontent">
                <a href="#"><h3>BRICKS</h3></a>
                <p>Nos 1  : Rs. 18/=</p>
                
            </div>
        </div>
        <div class="fourbox last_column">

            <div class="thumbbx"><a href="#"><img src="img/types/rubble.jpg" alt="" /></a></div>
            <div class="pagecontent">
                <a href="#"><h3>RUBBLE</h3></a>
                <p>1 Cube : Rs. 3800/=</p>
                
            </div>
        </div>

<br/><br/>
        <center><div class="fourbox last_column"><center>

            <div class="thumbbx"><a href="#"><img src="img/types/Soil.jpg" alt="" /></a></div>
            <div class="pagecontent">
                <a href="#"><h3>SOIL</h3></a>
                <p>1 Cube : Rs. 2000/=</p>
                
        </center></div></center>
        <div class="clear"></div>
    </div><!-- .container -->
</section><!-- #pagearea -->

    </body>
</html>
