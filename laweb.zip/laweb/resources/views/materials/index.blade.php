@extends('layouts.app')

@section('content')

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Materials</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="{{ route('material.create') }}"> Create New Item</a>
        </div>
    </div>
</div>

@if ($message = Session::get('success'))
<div class="alert alert-success">
    <p>{{ $message }}</p>
</div>
@endif

<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Material Name</th>
        <th>Price per 1 Cube</th>
        <th>Transportation 1KM</th>
        <th width="280px">Action</th>
    </tr>
    @foreach ($materials as $key => $item)
    <tr>
        <td>{{ ++$i }}</td>
        <td>{{ $item->mat_name }}</td>
        <td>{{ $item->mat_price }}</td>
        <td>{{ $item->mat_price_1km }}</td>
       <td>
            <a class="btn btn-primary" href="{{ route('material.edit',$item->id) }}">Edit</a>
            {!! Form::open(['method' => 'DELETE','route' => ['material.destroy', $item->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
        </td>
    </tr>
    @endforeach
</table>

{!! $materials->render() !!}

@endsection