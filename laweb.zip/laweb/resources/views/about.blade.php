<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>LA Consrution</title>
       {{-- <script src="{{ asset('js/app.js') }}"></script>--}}
        <script src="{{ asset('js/bootstrap.js') }}"></script>
        <script src="{{ asset('js/jquery.min.js') }}"></script>
        <script src="{{ asset('css/bootstrap.min.css') }}"></script>




        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet" />

        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #ffff00;
                color: #000000;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                /*height: 100vh;*/
                height: 10vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .top-left {
                position: absolute;
                left: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
                color: #000000;
                font-size: 16px;
                font-weight: 600;
                font-family: 'Raleway', sans-serif;

            }



            .title {
                font-size: 84px;
                font-weight: 100;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .custom1{
                font-size: 18px;
               /* color: #080808;!important;*/
                font-weight: 600;

            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">

            <div class="top-left links">
                <img src="img/logo.png" width="40" height="40" >
                <a href="{{ url('/') }}">Home</a>
                <a href="{{ url('/about') }}">About</a>
                <a href="{{ url('/gallery') }}">Gallery</a>
                <a href="{{ url('/contact') }}">Contact Us</a>
            </div>

            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/dashboard') }}">Retun to Dashboard</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                </div>
            @endif
        </div>
        <div class="header-search-box">

                <div class="search-box-wrap" >
                    <form role="search" method="get" class="search-form" action="https://www.gracethemes.com/demo/buildup/">
                        <label>
                            <span class="screen-reader-text">Search for:</span>
                            <input type="search" class="search-field" placeholder="Search&hellip;" value="" name="s" title="Search for:" />
                        </label>
                        <input type="submit" class="search-submit" class="fa fa-search" value="Search" /></form>                </div><!-- .search-box-wrap -->
            </div><!-- .header-search-box -->
            <div class="content">
{{-- Slide Goes Here--}}

                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#my<a href=" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>

                <div class="carousel-inner">
                    <div class="item active"> <img src="img/3.jpg" style="width:100%" data-src="holder.js/900x500/auto/#7cbf00:#fff/text: " alt="First slide">
                        <div class="container ">
                            <div class="carousel-caption" style="background-color:#8e9f93" >
                                <h1>Sand,Rubble,Metal,Soli etc </h1>
                                <p>Deliver to your doorstep</p>
                            </div>
                        </div>
                    </div>
                    <div class="item"> <img src="img/2.jpg" style="width:100%" data-src="" alt="Second slide">
                        <div class="container fontcolor">
                            <div class="carousel-caption" style="background-color:#8e9f93">
                                <h2>
                                Over 1000+ happy Customers
                                </h2>
                                <p> Since 2016,We have the largest customer base in Sri Lanka.</p>
                            </div>
                        </div>
                    </div>
                    <div class="item"> <img src="img/1.jpg" style="width:100%" data-src="" alt="Third slide">
                        <div class="container fontcolor">
                            <div class="carousel-caption" style="background-color:#8e9f93">
                                <h2>
                                   Best place to Start New
                                    </h2>
                                    <p> We have best quality products,</p>
                            </div>
                        </div>
                    </div>
                </div>

                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>

                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a><a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>

                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>

                </div>


{{--End Slide--}}

                <div class="content">
                    <!-- Main jumbotron for a primary marketing message or call to action -->
                    <div class="jumbotron">
                        <div class="container">
                            <h1 class="display-3">LA Constructions</h1>
                            <p>We supply Sand,Rubble,Metal,Soil and all other Construction materials</p>
                            <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
                        </div>
                    </div>

                    <div class="container">
                        <!-- Example row of columns -->
                        <div class="row">

                            <div class="col-md-6">
                                <h2>Vision</h2>
                                <p>To be the leading industrial group in nation-building; setting standards that
                                    exceed expectations in   Construction Industry with quality, excellence,
                                    a trusted and dependable partner.</p>
                                <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                            </div>
                            <div class="col-md-6">
                                <h2>Mission</h2>
                                <p>To stay committed to the Bench Mark Steel for
                                    the construction industry and infrastructure growth of Sri Lanka through
                                    empowering our people, driving innovation, pursuing sustainable development,
                                    assuring consistent quality, and committing to impeccable
                                    service to be an invaluable partner in the transformation
                                    of Sri Lanka as a developed country in near future.</p>
                                <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>
                            </div>
                        </div>
                    </div>

                        <div class="jumbotron">
                            <div class="container">
                                <h1 class="display-3">LA Constructions</h1>
                                <p>LA suppliers is a newly started sole proprietor construction company in 2017
                                    that supply building materials. This is situated in Kaduwela.We are hopping
                                    to supply building materials such as Sands, Metals, Bricks, Rubble, Soil.
                                    Also we hope to provide online ordering facility and check the price of order
                                    according to the distance to destination through this web site. Another feature
                                    is our customer can use any online pay method to deal with us.We try to be the
                                    leading industrial group that has made a giant contribution to the Construction
                                    Industry infrastructure growth and technological advancement in Sri Lanka.
                                    The RA suppliers Brand name being synonymous with quality, excellence,
                                    economy known as a household favorite, a trusted and dependable partner.</p>
                                <p><a class="btn btn-primary btn-lg" href="#" role="button">Learn more &raquo;</a></p>
                            </div>
                        </div>


                    </div>





        </div>
        <br>
        <br>
        <br>
        <hr>
        
    </body>
</html>
