<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>LA Consrution</title>
       {{-- <script src="{{ asset('js/app.js') }}"></script>--}}
        <script src="{{ asset('js/bootstrap.js') }}"></script>
        <script src="{{ asset('js/jquery.min.js') }}"></script>
        <script src="{{ asset('css/bootstrap.min.css') }}"></script>


<script>

    jQuery(document).ready(function($) {

        $('#myCarousel').carousel({
            interval: 5000
        });

        //Handles the carousel thumbnails
        $('[id^=carousel-selector-]').click(function () {
            var id_selector = $(this).attr("id");
            try {
                var id = /-(\d+)$/.exec(id_selector)[1];
                console.log(id_selector, id);
                jQuery('#myCarousel').carousel(parseInt(id));
            } catch (e) {
                console.log('Regex failed!', e);
            }
        });
        // When the carousel slides, auto update the text
        $('#myCarousel').on('slid.bs.carousel', function (e) {
            var id = $('.item.active').data('slide-number');
            $('#carousel-text').html($('#slide-content-'+id).html());
        });
    });




</script>

        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet" />

        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #000000;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                /*height: 100vh;*/
                height: 10vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .top-left {
                position: absolute;
                left: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
                color: #000000;
                font-size: 16px;
                font-weight: 600;
                font-family: 'Raleway', sans-serif;

            }



            .title {
                font-size: 84px;
                font-weight: 100;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .custom1{
                font-size: 18px;
               /* color: #080808;!important;*/
                font-weight: 600;

            }


            .hide-bullets {
                list-style:none;
                margin-left: -40px;
                margin-top:20px;
            }

            .thumbnail {
                padding: 0;
            }

            .carousel-inner>.item>img, .carousel-inner>.item>a>img {
                width: 100%;
            }



        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">

            <div class="top-left links">
                <img src="img/logo.png" width="40" height="40" >
                <a href="{{ url('/') }}">Home</a>
                <a href="{{ url('/about') }}">About</a>
                <a href="{{ url('/gallery') }}">Gallery</a>
                <a href="{{ url('/contact') }}">Contact Us</a>
            </div>

            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/dashboard') }}">Retun to Dashboard</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>
                        <a href="{{ route('register') }}">Register</a>
                    @endauth
                </div>
            @endif
        </div>
                    <div class="content">
{{-- Slide Goes Here--}}

                <div class="container">
                    <div id="main_area">
                        <!-- Slider -->
                        <div class="row">
                            <div class="col-sm-6" id="slider-thumbs">
                                <!-- Bottom switcher of slider -->
                                <ul class="hide-bullets">
                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-0">
                                            <img src="img/mat/1.jpg">
                                        </a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-1"><img src="img/mat/2.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-2"><img src="img/mat/3.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-3"><img src="img/mat/4.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-4"><img src="img/mat/5.png"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-5"><img src="img/mat/6.jpg"></a>
                                    </li>
                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-6"><img src="img/mat/7.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-7"><img src="img/mat/8.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-8"><img src="img/mat/9.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-9"><img src="img/mat/10.jpg"></a>
                                    </li>
                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-10"><img src="img/mat/11.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-11"><img src="img/mat/12.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-12"><img src="img/mat/13.jpg"></a>
                                    </li>

                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-14"><img src="img/mat/14.jpg"></a>
                                    </li>
                                    <li class="col-sm-3">
                                        <a class="thumbnail" id="carousel-selector-15"><img src="img/mat/15.jpg"></a>
                                    </li>

                                </ul>
                            </div>
                            <div class="col-sm-6">
                                <div class="col-xs-12" id="slider">
                                    <!-- Top part of the slider -->
                                    <div class="row">
                                        <div class="col-sm-12" id="carousel-bounding-box">
                                            <div class="carousel slide" id="myCarousel">
                                                <!-- Carousel items -->
                                                <div class="carousel-inner">
                                                    <div class="active item" data-slide-number="0">
                                                        <img src="img/mat/1.jpg"></div>

                                                    <div class="item" data-slide-number="1">
                                                        <img src="img/mat/2.jpg"></div>

                                                    <div class="item" data-slide-number="2">
                                                        <img src="img/mat/3.jpg"></div>

                                                    <div class="item" data-slide-number="3">
                                                        <img src="img/mat/4.jpg"></div>

                                                    <div class="item" data-slide-number="4">
                                                        <img src="img/mat/5.png"></div>

                                                    <div class="item" data-slide-number="5">
                                                        <img src="img/mat/6.jpg"></div>

                                                    <div class="item" data-slide-number="6">
                                                        <img src="img/mat/7.jpg"></div>

                                                    <div class="item" data-slide-number="7">
                                                        <img src="img/mat/8.jpg"></div>

                                                    <div class="item" data-slide-number="8">
                                                        <img src="img/mat/9.jpg"></div>

                                                    <div class="item" data-slide-number="9">
                                                        <img src="img/mat/10.jpg"></div>

                                                    <div class="item" data-slide-number="10">
                                                        <img src="img/mat/11.jpg"></div>

                                                    <div class="item" data-slide-number="11">
                                                        <img src="img/mat/12.jpg"></div>

                                                    <div class="item" data-slide-number="11">
                                                        <img src="img/mat/13.jpg"></div>

                                                    <div class="item" data-slide-number="11">
                                                        <img src="img/mat/14.jpg"></div>



                                                </div>
                                                <!-- Carousel nav -->
                                                <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                                                    <span class="glyphicon glyphicon-chevron-left"></span>
                                                </a>
                                                <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                                                    <span class="glyphicon glyphicon-chevron-right"></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--/Slider-->
                        </div>

                    </div>
                </div>





{{-- Slide Goes Here--}}

        </div>
        <br>
        <br>
        <br>
        <hr>
        
    </body>
</html>
