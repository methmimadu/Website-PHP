@extends('layouts.app')
<script src="{{ asset('js/jquery.min.js') }}"></script>
<script type="text/javascript">

    });
</script>
@section('content')

    <div class="row">
        <div class="col-md-6 col-md-offset-3 margin-tb align-center">
            <div class="pull-left">
                <h2>Place New Oder</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('order.index') }}"> Back</a>
            </div>
        </div>


    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    {!! Form::open(array('route' => 'order.store','method'=>'POST')) !!}


        <div class="row">{{--
            <div class="col-md-2 col-md-offset-4 margin-tb align-center">--}}
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-5">
                <strong>Material Name:</strong>
           {{--     {{ Form::select('mat_name', $materials, null, array(['id' => 'mat_name'],'class' => 'form-control')) }}--}}
                <select name="mat_name" id="mat_name" class="form-control">
                    @foreach($materials as $item)
                        <option value="{{ $item }}">{{ $item }}</option>
                    @endforeach
                </select>
            </div>
        </div>
            <div class="col-sm-6 col-sm-offset-3">
            <div class="form-group col-md-2">
                <strong>Quantity:</strong>
                {!! Form::number('qty', 1, array('placeholder' => 'Quantitiy','id'=>'qty','class' => 'form-control')) !!}
            </div>
        </div>
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-2">

                <strong>Price:</strong>
                {!! Form::text('price', '12000', array('id' => 'mat_price','class' => 'form-control' ,'readonly' => 'true' )) !!}
            </div>

        </div>
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-5">

                <strong>Distance ( in KM - Main Road ):</strong>
                {!! Form::number('distance', 1, array('id'=>'distance','class' => 'form-control')) !!}

        </div>
            </div>
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-2">
                <strong>Total:</strong>
                {!! Form::text('total', 0, array('id' => 'total','class' => 'form-control','readonly' => 'true')) !!}
            </div>
        </div>
            <div class="col-sm-6 col-sm-offset-6">

            <button type="button" id="cal" class="btn btn-success">Calculate Total</button>
            <button type="reset" id="reset" class="btn btn-danger">Reset</button>
            <button type="submit" class="btn btn-primary">Order</button>
        </div>


    </div>
    </div>
    {!! Form::close() !!}

@endsection