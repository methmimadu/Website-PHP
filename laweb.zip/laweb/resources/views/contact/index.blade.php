@extends('layouts.app')

@section('content')

<div class="row">
    <div class="col-md-6 col-md-offset-2 margin-tb">
        <div class="pull-left">
            <h2>Messages</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="{{ route('dashboard') }}"> dashboard</a>
        </div>
    </div>
</div>

@if ($message = Session::get('success'))
<div class="alert alert-success">
    <p>{{ $message }}</p>
</div>
@endif
<div class="row">
    <div class="col-md-6 col-md-offset-2 margin-tb">
<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Customer Name</th>
        <th>Customer Email</th>
        <th>Subject</th>
        <th>Mmessage</th>

    </tr>
    @foreach ($contact as $key => $item)
    <tr>
        <td>{{ ++$i }}</td>
        <td>{{ $item->name }}</td>
        <td>{{ $item->email }}</td>
        <td>{{ $item->sub }}</td>
        <td>{{ $item->msg }}</td>

    </tr>
    @endforeach
</table>
    </div></div>
{!! $contact->render() !!}

@endsection