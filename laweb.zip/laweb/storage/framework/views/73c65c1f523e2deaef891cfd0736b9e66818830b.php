<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="flex-center position-ref full-height">
        
    </div>
    <div class="row">
        <div class="col-md-12 col-md-offset">
            <div class="panel panel-default">

                <div class="panel-heading">Welcome
                    <?php if( Auth::user()->admin): ?>

                   <b>Admin</b>  <?php endif; ?>
                    <?php echo e(Auth::user()->name); ?></div>


                <div class="row">
                <div class="col-md-8 col-md-offset-2">

                    <br><br>
                    <?php if(Route::has('login')): ?>
                        <div class="top-right links">
                            <?php if( Auth::user()->admin): ?>

                                

                               

                                <a href="<?php echo e(url('/material')); ?>"> <button type="button" class="btn btn-success btn-cons">Update Materials</button></a>
                                <a href="<?php echo e(url('/material/create')); ?>"> <button type="button" class="btn btn-success btn-cons">Add New Materials</button></a>
                                <a href="<?php echo e(url('/order')); ?>"> <button type="button" class="btn btn-success btn-cons">All Orders</button></a>
                                <a href="<?php echo e(url('/order/create')); ?>"> <button type="button" class="btn btn-success btn-cons">Add a Manual Order</button></a>
                                <a href="<?php echo e(url('/contact1')); ?>"> <button type="button" class="btn btn-success btn-cons">Messages</button></a>

                                
                             


                            <?php else: ?>
                                <a href="<?php echo e(url('/order/create')); ?>"> <button type="button" class="btn btn-success btn-cons">Place a Order</button></a>
                                    
                            <?php endif; ?>

                            
                        </div>
                    <?php endif; ?>

 <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>


                    <br><br>

    <p>

    We warmly welcome you for our website. This is your personal account in LA Suppliers web site. Only you can use this account until you keep your password secretly. You can , <br>
• Update material information. <br>
• Add new material.<br>
• Check all martials.<br>
• Add manual orders.<br>
• Check messages from customers.<br>
Via this account. We hope that you will dedicate to serve a valuable service for our customers. 


        </p>
                </div></div>

            </div>
        </div>
    </div>
    
    


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>