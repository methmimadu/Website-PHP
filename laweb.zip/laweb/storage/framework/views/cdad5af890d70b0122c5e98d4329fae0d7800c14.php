<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-6 col-md-offset-2 margin-tb">
        <div class="pull-left">
            <h2>Messages</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('dashboard')); ?>"> dashboard</a>
        </div>
    </div>
</div>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>
<div class="row">
    <div class="col-md-6 col-md-offset-2 margin-tb">
<table class="table table-bordered">
    <tr>
        <th>No</th>
        <th>Customer Name</th>
        <th>Customer Email</th>
        <th>Subject</th>
        <th>Mmessage</th>

    </tr>
    <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(++$i); ?></td>
        <td><?php echo e($item->name); ?></td>
        <td><?php echo e($item->email); ?></td>
        <td><?php echo e($item->sub); ?></td>
        <td><?php echo e($item->msg); ?></td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
    </div></div>
<?php echo $contact->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>