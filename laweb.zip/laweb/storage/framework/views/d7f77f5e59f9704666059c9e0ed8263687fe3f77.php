<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        var mat = $("#mat_name").val();
        if(mat === 'Sand'){

            $("#mat_price").val('12000')
        }
        $('#mat_name').change(function(){

            var mat = $("#mat_name").val();

           if(mat == 'Sand'){

               $("#mat_price").val('12000')
           }
                else if(mat == 'Metal'){
               $("#mat_price").val('14000')

            }
                else if(mat == 'Bricks'){
               $("#mat_price").val('8000')

            }
                else if(mat == 'Rubble'){
               $("#mat_price").val('9000')
            }
                else if(mat == 'Soil'){
               $("#mat_price").val('3000')
            }
                else if(mat == 'Sand 2'){
               $("#mat_price").val('15000')

            }else {

               $("#mat_price").val('10000')
            }


        });

        $('#cal').click(function(){

            var price = $("#mat_price").val()
            var dis = $("#distance").val()
            var qty = $("#qty").val()


            var tot = parseInt(qty)*parseInt(price)+dis*200*parseInt(qty);

            $("#total").val(tot)


         });

        /*$('#reset').click(function(){
            $("#mat_price").val('12000')
        });*/


    });
</script>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-6 col-md-offset-3 margin-tb align-center">
            <div class="pull-left">
                <h2>Place New Oder</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('order.index')); ?>"> Back</a>
            </div>
        </div>


    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo Form::open(array('route' => 'order.store','method'=>'POST')); ?>



        <div class="row">
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-5">
                <strong>Material Name:</strong>
           
                <select name="mat_name" id="mat_name" class="form-control">
                    <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
            <div class="col-sm-6 col-sm-offset-3">
            <div class="form-group col-md-2">
                <strong>Quantity:</strong>
                <?php echo Form::number('qty', 1, array('placeholder' => 'Quantitiy','id'=>'qty','class' => 'form-control')); ?>

            </div>
        </div>
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-2">

                <strong>Price:</strong>
                <?php echo Form::text('price', '12000', array('id' => 'mat_price','class' => 'form-control' ,'readonly' => 'true' )); ?>

            </div>

        </div>
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-5">

                <strong>Distance ( in KM - Main Road ):</strong>
                <?php echo Form::number('distance', 1, array('id'=>'distance','class' => 'form-control')); ?>


        </div>
            </div>
            <div class="col-sm-6 col-sm-offset-3">
                <div class="form-group col-md-2">
                <strong>Total:</strong>
                <?php echo Form::text('total', 0, array('id' => 'total','class' => 'form-control','readonly' => 'true')); ?>

            </div>
        </div>
            <div class="col-sm-6 col-sm-offset-6">

            <button type="button" id="cal" class="btn btn-success">Calculate Total</button>
            <button type="reset" id="reset" class="btn btn-danger">Reset</button>
            <button type="submit" class="btn btn-primary">Order</button>
        </div>


    </div>
    </div>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>