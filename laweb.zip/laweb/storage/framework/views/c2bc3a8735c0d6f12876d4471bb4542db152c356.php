<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>LA Consrution</title>
       
        <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('css/bootstrap.min.css')); ?>"></script>
        <script src="<?php echo e(asset('css/app.css')); ?>"></script>




        <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet" />

        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

        <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #ffff00;
                color: #000000;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                /*height: 100vh;*/
                height: 10vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .top-left {
                position: absolute;
                left: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
                color: #000000;
                font-size: 16px;
                font-weight: 600;
                font-family: 'Raleway', sans-serif;

            }



            .title {
                font-size: 84px;
                font-weight: 100;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .custom1{
                font-size: 18px;
               /* color: #080808;!important;*/
                font-weight: 600;

            }

            /*JunbSty*/
            .jumbotron {
                background: #358CCE;
                color: #FFF;
                border-radius: 0px;
            }
            .jumbotron-sm { padding-top: 24px;
                padding-bottom: 24px; }
            .jumbotron small {
                color: #FFF;
            }
            .h1 small {
                font-size: 24px;
            }





        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">

            <div class="top-left links">

                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/about')); ?>">About</a>
                <a href="<?php echo e(url('/gallery')); ?>">Gallery</a>
                <a href="<?php echo e(url('/contact')); ?>">Contact Us</a>
            </div>

            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/dashboard')); ?>">Retun to Dashboard</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="header-search-box">

                <div class="search-box-wrap" >
                    <form role="search" method="get" class="search-form" action="https://www.gracethemes.com/demo/buildup/">
                        <label>
                            <span class="screen-reader-text">Search for:</span>
                            <input type="search" class="search-field" placeholder="Search&hellip;" value="Search" name="s" title="Search for:" />
                        </label>
                        <input type="submit" class="search-submit" class="fa fa-search" value="Search" /></form>                </div><!-- .search-box-wrap -->
            </div><!-- .header-search-box -->
        
            <div class="content">


                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#my<a href=" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>

                <div class="carousel-inner">
                    <div class="item active"> <img src="img/3.jpg" style="width:100%" data-src="holder.js/900x500/auto/#7cbf00:#fff/text: " alt="First slide">
                        <div class="container ">
                            <div class="carousel-caption" style="background-color:#8e9f93" >
                                <h1>Sand,Rubble,Metal,Soli etc </h1>
                                <p>Deliver to your doorstep</p>
                            </div>
                        </div>
                    </div>
                    <div class="item"> <img src="img/2.jpg" style="width:100%" data-src="" alt="Second slide">
                        <div class="container fontcolor">
                            <div class="carousel-caption" style="background-color:#8e9f93">
                                <h2>
                                Over 1000+ happy Customers
                                </h2>
                                <p> Since 2016,We have the largest customer base in Sri Lanka.</p>
                            </div>
                        </div>
                    </div>
                    <div class="item"> <img src="img/1.jpg" style="width:100%" data-src="" alt="Third slide">
                        <div class="container fontcolor">
                            <div class="carousel-caption" style="background-color:#8e9f93">
                                <h2>
                                   Best place to Start New
                                    </h2>
                                    <p> We have best quality products,</p>
                            </div>
                        </div>
                    </div>
                </div>

                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>

                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a><a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                </a>

                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                </a>

                </div>




                <div class="content">
                    <div class="jumbotron jumbotron-sm">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-12 col-lg-12">
                                    <h1 class="h1">
                                        Contact us <small>Feel free to contact us</small></h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="well well-sm">
                                        <div class="row">
                                            <div class="col-md-6">
                                              

                                                <div class="flash-message">

                                                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(Session::has('alert-' . $msg)): ?>

                                                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div> <!-- end .flash-message -->


                                <?php echo Form::open(array('route' => 'contact1.store','method'=>'POST')); ?>

                                                <div class="form-group">
                                                    <label for="name1">
                                                        Name</label>
                                                    <input type="text" name="name" class="form-control" id="name" placeholder="Enter name" required="required" />
                                                </div>
                                                <div class="form-group">
                                                    <label for="email1">
                                                        Email Address</label>
                                                    <div class="input-group">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span>
                                </span>
                                                        <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" required="required" /></div>
                                                </div>
                                                <div class="form-group">
                                                    <label for="subject">
                                                        Subject</label>
                                                    <select id="subject" name="sub" class="form-control" required="required">
                                                        <option value="na" selected="">Choose One:</option>
                                                        <option value="service">General Customer Service</option>
                                                        <option value="suggestions">Suggestions</option>
                                                        <option value="product">Product Support</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="name11">
                                                        Message</label>
                                                    <textarea name="msg" id="message" class="form-control" rows="9" cols="25" required="required"
                                                              placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-md-12">


                                                <button type="submit" class="btn btn-primary pull-right" id="btnContactUs">
                                                    Send Message</button>
                                            </div>
                                            <?php echo e(Form:: close()); ?>

                                        </div>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <form>
                                    <legend><span class="glyphicon glyphicon-globe"></span> Our office</legend>
                                    <address>
                                        <strong>LA Construction.</strong><br>
                                        160/1/1, Mahawaththa Road<br>
                                        Palanwaththa,<br>
                                        Pannipitiya, Sri Lanka<br>
                                        <abbr title="Phone">
                                            Tel:</abbr>
                                        +774284639
                                    </address>
                                    <address>
                                        <strong>Email</strong><br>
                                        <a href="mailto:#">lasuppliers63@gmail.com</a>
                                    </address>
                                </form>
                            </div>
                        </div>
                    </div>


                 
                        



                    </div>




                    
                    <div class="container">
                        <div class="row-fluid">
                            <div class="span8">
                                <iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3961.5485379643565!2d79.9584683739616!3d6.824629336316907!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ae2502daed63ce9%3A0x7e7813e42712a0f6!2sSummerfield%60s!5e0!3m2!1sen!2slk!4v1510644048658"></iframe>
                            </div>


                        </div>
                    </div>


        </div>
        <br>
        <br>
        <br>
        <hr>
       

            </div>
    </body>
</html>
