<?php $__env->startSection('content'); ?>


    <div class="container">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        <div class="container">
            <div class="fb-profile">
                <img align="left" class="fb-image-lg" src="img/pr_bg.jpg" alt=""/>
                <img align="left" class="fb-image-profile thumbnail" src="img/pro.png" alt=""/>
                <div class="fb-profile-text">
                    <h1><?php echo e(Auth::user()->name); ?></h1>
                    <p>Welcome</p>
                </div>
            </div>
        </div> <!-- /container -->



        <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Profile Page</div>

                <div class="panel-body">

                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <br>
                    <h1><B>User Id :</B> 00000<?php echo e(Auth::user()->id); ?></h1>
                     <h1><B>User Name :</B><?php echo e(Auth::user()->name); ?></h1>
                     <h1><B>User Email :</B> <?php echo e(Auth::user()->email); ?></h1>
                        Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add. You can also type a keyword to search online for the video that best fits your document.
                        To make your document look professionally produced, Word provides header, footer, cover page, and text box designs that complement each other. For example, you can add a matching cover page, header, and sidebar. Click Insert and then choose the elements you want from the different galleries.
                        Themes and styles also help keep your document coordinated. When you click Design and choose a new Theme, the pictures, charts, and SmartArt graphics change to match your new theme. When you apply styles, your headings change to match the new theme.
                        <br>
                        <br>
                    You are logged in!
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>