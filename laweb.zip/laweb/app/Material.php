<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Material extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    public $fillable = [
        'mat_name', 'mat_price', 'mat_price_1km',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */

}
