<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Material;

class MaterialController extends Controller
{

    public function index(Request $request)
    {
        $materials = Material::orderBy('id', 'DESC')->paginate(5);
        return view('Materials.index', compact('materials'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    public function create()
    {
        return view('materials.create');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'mat_name' => 'required',
            'mat_price' => 'required',
            'mat_price_1km' => 'required',
        ]);

        Material::create($request->all());
        return redirect()->route('material.index')
            ->with('success', 'Material created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
//    public function show($id)
//    {
//        $item = Item::find($id);
//        return view('ItemCRUD.show', compact('item'));
//    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $material = Material::find($id);
        return view('materials.edit', compact('material'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'mat_name' => 'required',
            'mat_price' => 'required',
            'mat_price_1km' => 'required',
        ]);

        Material::find($id)->update($request->all());
        return redirect()->route('material.index')
            ->with('success', 'Material updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Material::find($id)->delete();
        return redirect()->route('material.index')
            ->with('success', 'Material deleted successfully');
    }

}
