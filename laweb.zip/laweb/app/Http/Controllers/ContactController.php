<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Mail\Mailer;
use App\Contact;
use App\User;
use Auth;


class ContactController extends Controller
{
    public function index(Request $request)
    {

        $contact = Contact::orderBy('id', 'ASC')->paginate(5);
        return view('contact.index', compact('contact'))
            ->with('i', ($request->input('page', 1) - 1) * 5);

    }

    public function create()
    {

        // $materials = Material::pluck('mat_name');

      /*  $materials = Material::pluck('mat_name','mat_price');
        return view('order.create', compact('materials'));*/
    }

    public function store(Request $request)
    {
        $this->validate($request, [

            'name' => 'required',
            'email' => 'required',
            'sub' => 'required',
            'msg' => 'required',

        ]);

        Contact::create($request->all());
        return redirect()->route('contact')
            ->with('success', 'Message Sent successfully');
    }



}
