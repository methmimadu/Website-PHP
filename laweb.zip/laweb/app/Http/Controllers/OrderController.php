<?php

namespace App\Http\Controllers;

use App\Material;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Order;
use App\User;
use Auth;

class OrderController extends Controller
{

    public function index(Request $request)
    {
         $user = Auth::user()->admin;

       if ($user) {
            $order = Order::orderBy('id', 'ASC')->paginate(5);
        return view('order.index', compact('order'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
        }

        return redirect()->route('dashboard')
            ->with('success', 'Order created successfully');

    }

    public function create()
    {

       // $materials = Material::pluck('mat_name');

        $materials = Material::pluck('mat_name','mat_price');
        return view('order.create', compact('materials'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
           // 'cust_name' => 'required',

           // 'cust_name' => Auth::user()->name,
            'mat_name' => 'required',
            'qty' => 'required',
            'price' => 'required',
            'distance' => 'required',
            'total' => 'required',

        ]);

        $request->request->add(['cust_name' => Auth::user()->name]);
        $request->request->add(['cust_email' => Auth::user()->email]);

        Order::create($request->all());
        return redirect()->route('order.index')
            ->with('success', 'Order created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
//    public function show($id)
//    {
//        $item = Item::find($id);
//        return view('ItemCRUD.show', compact('item'));
//    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $order = Order::find($id);
        return view('order.edit', compact('order'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'mat_name' => 'required',
            'mat_price' => 'required',
            'mat_price_1km' => 'required',
        ]);

        Material::find($id)->update($request->all());
        return redirect()->route('material.index')
            ->with('success', 'Material updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Order::find($id)->delete();
        return redirect()->route('order.index')
            ->with('success', 'Material deleted successfully');
    }

}
